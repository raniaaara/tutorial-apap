package apap.tutorial.haidokter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaidokterApplicationTests {

	@Test
	void contextLoads() {
	}

}
