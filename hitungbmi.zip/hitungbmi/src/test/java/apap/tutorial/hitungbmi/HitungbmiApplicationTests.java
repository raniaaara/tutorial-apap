package apap.tutorial.hitungbmi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HitungbmiApplicationTests {

	@Test
	void contextLoads() {
	}

}
